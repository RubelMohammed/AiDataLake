# This is an auto-generated Django model module.
# You'll have to do the following manually to clean this up:
#   * Rearrange models' order
#   * Make sure each model has one field with primary_key=True
#   * Make sure each ForeignKey and OneToOneField has `on_delete` set to the desired behavior
#   * Remove `managed = False` lines if you wish to allow Django to create, modify, and delete the table
# Feel free to rename the models, but don't rename db_table values or field names.
from django.db import models
from django.contrib.auth.models import User


class DataRepresentation(models.Model):
    id = models.IntegerField(primary_key=True)
    dbname = models.TextField(db_column='dbName')  # Field name made lowercase.
    elementname = models.TextField(db_column='elementName')  # Field name made lowercase.
    datatype = models.TextField(db_column='dataType')  # Field name made lowercase.
    tablecolumn = models.IntegerField(db_column='tableColumn')  # Field name made lowercase.
    localgroupingkey = models.IntegerField(db_column='localGroupingKey')  # Field name made lowercase.


    class Meta:
        managed=False
        db_table = 'datarepresentation'


class RequestHistory(models.Model):
    id = models.IntegerField(primary_key=True)
    dbreferenced = models.TextField(db_column='dbReferenced')  # Field name made lowercase.
    tablereferenced = models.IntegerField(db_column='tableReferenced')  # Field name made lowercase.
    requesttext = models.TextField(db_column='requestText')  # Field name made lowercase.
    sqloutput = models.TextField(db_column='sqlOutput')  # Field name made lowercase.
    metageneration = models.TextField(db_column='metaGeneration')  # Field name made lowercase.
    datetime = models.DateField(db_column='dateTime')  # Field name made lowercase.

    class Meta:
        managed=False
        db_table = 'requesthistory'


class RequestTable(models.Model):
    id = models.IntegerField(primary_key=True)
    requesttype = models.IntegerField(db_column='requestType')  # Field name made lowercase.
    requesttext = models.TextField(db_column='requestText')  # Field name made lowercase.
    requestdatetime = models.DateTimeField(db_column='requestDateTime')  # Field name made lowercase.

    class Meta:
        managed=False
        db_table = 'requesttable'


class UserLogin(models.Model):
    id = models.IntegerField(primary_key=True)
    username = models.TextField()
    password = models.TextField()
    dateaccountcreated = models.DateField(db_column='dateAccountCreated')  # Field name made lowercase.
    loginstatus = models.IntegerField(db_column='loginStatus')  # Field name made lowercase.

    class Meta:
        managed=False
        db_table = 'userlogin'
