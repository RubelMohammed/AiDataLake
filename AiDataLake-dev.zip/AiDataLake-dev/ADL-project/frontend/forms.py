from django import forms
from django.db import models
from django.forms import fields
from .models import *

class questionForm(forms.ModelForm):
    class Meta:
        model = UserLogin
        fields = '__all__'